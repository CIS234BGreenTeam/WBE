﻿Public Class DriverDB
    Public Shared Sub SetupAdapter()

    End Sub
End Class
