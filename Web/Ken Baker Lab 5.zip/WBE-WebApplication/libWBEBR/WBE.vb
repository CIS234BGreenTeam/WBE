﻿Public Class WBE
    Public Property Customer As List(Of Customer)
    Public Property BakedGood As List(Of BakedGood)
    Public Property Driver As List(Of Driver)
End Class
